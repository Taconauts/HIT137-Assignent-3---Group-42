
import tkinter as tk
from controller import Controller
from views.home_view import HomeView
from views.input_view import InputView
from results_view import ResultsView

class Application(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("HIT137 Assignment 3 - AI GUI")
        self.geometry("640x560")

        self.controller = Controller()
        self._view = None
        self.show_home()

    def _swap(self, view):
        if self._view:
            self._view.destroy()
        self._view = view
        self._view.pack(fill="both", expand=True)

    def show_home(self):
        self._swap(HomeView(self, self))

    def show_input(self, model_name: str):
        self._swap(InputView(self, self, model_name))

    def show_results(self, model_name: str, input_data, result: dict):
        self._swap(ResultsView(self, self, model_name, input_data, result))

if __name__ == "__main__":
    app = Application()
    app.mainloop()
