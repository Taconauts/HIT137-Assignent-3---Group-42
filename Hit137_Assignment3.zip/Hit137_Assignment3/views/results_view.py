import tkinter as tk
from tkinter import filedialog, messagebox
from PIL import Image, ImageTk
import json
import os

class ResultsView(tk.Frame):
    def __init__(self, master, app, model_name: str, input_data, result: dict):
        super().__init__(master)
        self.app = app
        self.model_name = model_name
        self._img_ref = None
        self._last_payload = {"model": model_name, "input": input_data, "result": result}

        tk.Label(self, text=f"Results – {model_name}", font=("Arial", 16)).pack(pady=10)

        if model_name == "Image Classification":
            self._render_classification(input_data, result)
        elif model_name == "Image Captioning":
            self._render_caption(input_data, result)
        else:
            tk.Label(self, text=json.dumps(result, indent=2)).pack()

        btns = tk.Frame(self); btns.pack(pady=12)
        tk.Button(btns, text="Save Output", command=self._save_output).grid(row=0, column=0, padx=6)
        tk.Button(btns, text="Run another", command=self.app.show_home).grid(row=0, column=1, padx=6)

    def _thumb(self, path):
        img = Image.open(path).convert("RGB")
        img.thumbnail((380, 380))
        tkimg = ImageTk.PhotoImage(img)
        return img, tkimg

    def _render_classification(self, image_path, result):
        _, tkimg = self._thumb(image_path)
        self._img_ref = tkimg
        tk.Label(self, image=tkimg).pack()
        tk.Label(self, text=f"Label: {result.get('label')}").pack(pady=4)
        score = result.get('score')
        if isinstance(score, float):
            tk.Label(self, text=f"Score: {score:.3f}").pack()

    def _render_caption(self, image_path, result):
        _, tkimg = self._thumb(image_path)
        self._img_ref = tkimg
        tk.Label(self, image=tkimg).pack()
        tk.Label(self, wraplength=520, text=f"Caption: {result.get('caption')}").pack(pady=6)

    def _save_output(self):
        try:
            default_name = f"{self.model_name.replace(' ', '_').lower()}_result.json"
            path = filedialog.asksaveasfilename(
                title="Save result",
                defaultextension=".json",
                initialfile=default_name,
                filetypes=[("JSON", "*.json")]
            )
            if not path:
                return
            with open(path, "w", encoding="utf-8") as f:
                json.dump(self._last_payload, f, ensure_ascii=False, indent=2)
            messagebox.showinfo("Saved", f"Saved to:\n{os.path.abspath(path)}")
        except Exception as e:
            messagebox.showerror("Save failed", str(e))
