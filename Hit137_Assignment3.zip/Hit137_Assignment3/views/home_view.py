import tkinter as tk

class HomeView(tk.Frame):
    def __init__(self, master, controller):
        super().__init__(master)
        self.controller = controller
        tk.Label(self, text="Choose a Model", font=("Arial", 16)).pack(pady=10)

        self.model_var = tk.StringVar(value="Text-to-Image")
        options = ["Text-to-Image", "Image Classification"]
        tk.OptionMenu(self, self.model_var, *options).pack()

        tk.Button(self, text="Next", command=self.on_next).pack(pady=20)

    def on_next(self):
        chosen = self.model_var.get()
        self.controller.show_input(chosen)
