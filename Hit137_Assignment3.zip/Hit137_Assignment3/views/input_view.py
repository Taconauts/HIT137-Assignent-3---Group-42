import tkinter as tk
from tkinter import filedialog, messagebox
from PIL import Image, ImageTk

IMAGE_MODELS = {"Image Classification", "Image Captioning"}

class InputView(tk.Frame):
    def __init__(self, master, app, model_name: str):
        super().__init__(master)
        self.app = app
        self.model_name = model_name
        self.image_path = None
        self._preview_ref = None

        tk.Label(self, text=f"Input – {model_name}", font=("Arial", 16)).pack(pady=10)

        if model_name in IMAGE_MODELS:
            self._build_image_inputs()
        else:
            tk.Label(self, text="No inputs required for this model.").pack(pady=10)

        btns = tk.Frame(self)
        btns.pack(pady=10)
        tk.Button(btns, text="Run", command=self._on_run).grid(row=0, column=0, padx=5)
        tk.Button(btns, text="Back", command=self.app.show_home).grid(row=0, column=1, padx=5)

    def _build_image_inputs(self):
        row = tk.Frame(self); row.pack(pady=8)
        tk.Button(row, text="Choose Image…", command=self._choose_image).pack(side=tk.LEFT)
        self.path_lbl = tk.Label(row, text="No file chosen", anchor="w", width=60)
        self.path_lbl.pack(side=tk.LEFT, padx=10)

        self.preview_lbl = tk.Label(self)
        self.preview_lbl.pack(pady=10)

    def _choose_image(self):
        path = filedialog.askopenfilename(
            title="Select image",
            filetypes=[("Image files", "*.png *.jpg *.jpeg *.bmp *.webp")]
        )
        if not path:
            return
        self.image_path = path
        self.path_lbl.config(text=path)

        # show small preview
        try:
            img = Image.open(path).convert("RGB")
            img.thumbnail((320, 320))
            tkimg = ImageTk.PhotoImage(img)
            self._preview_ref = tkimg  # keep ref to prevent GC
            self.preview_lbl.config(image=tkimg)
        except Exception as e:
            messagebox.showerror("Image error", str(e))

    def _on_run(self):
        try:
            if self.model_name in IMAGE_MODELS and not self.image_path:
                messagebox.showwarning("Missing input", "Please choose an image first.")
                return
            input_data = self.image_path if self.image_path else None
            result = self.app.controller.run_model(self.model_name, input_data)
            self.app.show_results(self.model_name, input_data, result)
        except Exception as e:
            messagebox.showerror("Run failed", str(e))
