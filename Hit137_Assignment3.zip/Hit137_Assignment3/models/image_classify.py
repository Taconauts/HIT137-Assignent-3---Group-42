from transformers import pipeline
from .model_base import AIModel

class ImageClassificationModel(AIModel):
    def __init__(self):
        super().__init__(
            "Image Classification",
            "Classifies an image into labels using a ViT model."
        )
        self._pipe = pipeline("image-classification", model="google/vit-base-patch16-224")

    def predict(self, image_path: str):
        results = self._pipe(image_path)
        top = results[0]
        return {"label": top["label"], "score": float(top["score"])}
