from abc import ABC, abstractmethod

class AIModel(ABC):
    def __init__(self, name, description):
        self._name = name
        self._description = description

    @abstractmethod
    def predict(self, input_data):
        pass

    def get_info(self):
        return {"name": self._name, "description": self._description}
