from transformers import pipeline
from .model_base import AIModel

class ImageCaptionModel(AIModel):
    def __init__(self):
        super().__init__(
            "Image Captioning",
            "Generates a caption from an input image using a Transformers pipeline."
        )
        # downloads on first run
        self._pipe = pipeline("image-to-text", model="nlpconnect/vit-gpt2-image-captioning")

    def predict(self, image_path: str):
        result = self._pipe(image_path)
        # result is a list like: [{'generated_text': '...'}]
        return {"caption": result[0]["generated_text"]}
