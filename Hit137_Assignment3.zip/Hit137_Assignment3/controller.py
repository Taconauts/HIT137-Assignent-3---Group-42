import time
from models.text2image import ImageCaptionModel
from models.image_classify import ImageClassificationModel

def measure_time(fn):
    def wrapper(*args, **kwargs):
        start = time.time()
        try:
            return fn(*args, **kwargs)
        finally:
            print(f"{fn.__name__} took {time.time() - start:.2f}s")
    return wrapper

class Controller:
    def __init__(self):
        self.models = {
            "Image Captioning": ImageCaptionModel(),
            "Image Classification": ImageClassificationModel(),
        }

    def get_model_names(self):
        return list(self.models.keys())

    @measure_time
    def run_model(self, model_name, input_data):
        model = self.models.get(model_name)
        if not model:
            raise ValueError(f"Unknown model: {model_name}")
        return model.predict(input_data)

    def get_model_info(self, model_name):
        model = self.models.get(model_name)
        return model.get_info() if model else {}
